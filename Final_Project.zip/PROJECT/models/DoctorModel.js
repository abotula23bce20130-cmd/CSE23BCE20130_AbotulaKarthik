import mongoose from "mongoose";

const doctorSchema = new mongoose.Schema({
    fullname:{type: String, required: true},
    email:{type: String, required: true, unique: true},
    phone:{type: String, required: true,unique: true},
    password:{type: String, required: true},
    specialization: {type: String, required: true},
    experience: {type: Number,required: true,min: 0},
    qualification: {type: String,required: true}
},{
    timestamps:true
})

const Doctor = mongoose.models.Doctor || mongoose.model("Doctor",doctorSchema)

export default Doctor